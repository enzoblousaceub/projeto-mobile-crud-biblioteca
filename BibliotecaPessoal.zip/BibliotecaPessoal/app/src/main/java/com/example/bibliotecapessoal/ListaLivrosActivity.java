package com.example.bibliotecapessoal;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bibliotecapessoal.adapter.AdapterLivro;
import com.example.bibliotecapessoal.model.Livro;
import com.example.bibliotecapessoal.persistencia.LivroDAO;

import java.util.List;

public class ListaLivrosActivity extends AppCompatActivity {

    public static final String EXTRA_LIVRO = "livroSelecionado";

    private RecyclerView recyclerLivros;
    private TextView textListaVazia;
    private AdapterLivro adapter;
    private LivroDAO dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_lista_livros);
        // bottom = 0: o BottomNavigationView já trata a margem inferior
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, 0);
            return insets;
        });

        NavegacaoMenu.configurar(this, R.id.nav_livros);

        dao = new LivroDAO(getApplicationContext());
        recyclerLivros = findViewById(R.id.recyclerLivros);
        textListaVazia = findViewById(R.id.textListaVazia);

        adapter = new AdapterLivro(null);
        recyclerLivros.setLayoutManager(new LinearLayoutManager(this));
        recyclerLivros.setHasFixedSize(true);
        recyclerLivros.addItemDecoration(
                new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        recyclerLivros.setAdapter(adapter);

        recyclerLivros.addOnItemTouchListener(new RecyclerItemClickListener(
                getApplicationContext(), recyclerLivros,
                new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        if (position == RecyclerView.NO_POSITION) return;
                        abrirEdicao(adapter.getLivro(position));
                    }

                    @Override
                    public void onLongItemClick(View view, int position) {
                        if (position == RecyclerView.NO_POSITION) return;
                        confirmarExclusao(adapter.getLivro(position));
                    }
                }));
    }

    @Override
    protected void onResume() {
        super.onResume();
        carregarLivros();
    }

    // Busca os livros no banco e atualiza o adapter
    private void carregarLivros() {
        List<Livro> livros = dao.listarTodos();
        adapter.atualizarLista(livros);
        textListaVazia.setVisibility(livros.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void abrirEdicao(Livro livro) {
        Intent intent = new Intent(this, CadastroLivroActivity.class);
        intent.putExtra(EXTRA_LIVRO, livro);
        NavegacaoMenu.irPara(this, intent);
    }

    private void confirmarExclusao(Livro livro) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.dialogo_excluir_titulo)
                .setMessage(getString(R.string.dialogo_excluir_mensagem, livro.getTitulo()))
                .setPositiveButton(R.string.dialogo_sim, (dialog, which) -> {
                    if (dao.excluir(livro)) {
                        Toast.makeText(this, R.string.msg_excluido_sucesso, Toast.LENGTH_SHORT).show();
                        carregarLivros();
                    } else {
                        Toast.makeText(this, R.string.msg_excluido_erro, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(R.string.dialogo_nao, null)
                .show();
    }
}
