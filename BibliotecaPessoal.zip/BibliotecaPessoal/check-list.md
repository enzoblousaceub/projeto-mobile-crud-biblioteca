# Check-list — App Biblioteca Pessoal

Referência: `Exercicio_Avaliativo_Biblioteca_Pessoal.md` (e o PDF original).
Legenda: `[x]` pronto · `[ ]` pendente

## Passo 1 — Criação e configuração do projeto
- [x] Projeto "Biblioteca Pessoal", pacote `com.example.bibliotecapessoal`, Java
- [x] `MainActivity` renomeada para `ListaLivrosActivity` (LAUNCHER no manifest)
- [x] Dependência `com.google.android.material:material` declarada
- [x] Pacotes `model`, `persistencia` e `adapter` criados

## Passo 2 — Camada de dados
- [x] `model/Livro.java` — id (Long), titulo, autor, ano (int), lido (boolean), `Serializable`, construtores, getters/setters
- [x] `persistencia/DbHelper.java` — constantes `public static final` (banco, versão 1, tabela `livros`, colunas) **(RT03)**
- [x] `DbHelper.onCreate` — `CREATE TABLE` com `lido INTEGER DEFAULT 0`
- [x] `DbHelper.onUpgrade` — `ALTER TABLE livros ADD COLUMN nota INTEGER` quando `oldVersion < 2`, sem DROP **(RT03)**
- [x] `persistencia/ILivroDAO.java` — `salvar`, `atualizar`, `excluir`, `listarTodos`, `contar(Boolean)` **(RT01)**
- [x] `persistencia/LivroDAO.java` — conversão boolean ↔ INTEGER (`isLido() ? 1 : 0` / `getInt(...) == 1`)
- [x] `LivroDAO` valida retornos: insert ≠ -1, update > 0, delete > 0 **(RT02)**
- [x] `LivroDAO.listarTodos` ordenado por `titulo ASC` **(RF02)**
- [x] `LivroDAO.contar` com `SELECT COUNT(*)` (null = total, true = lidos, false = não lidos) **(RF05)**

## Passo 3 — Recursos visuais e navegação
- [x] Todas as cores em `colors.xml` **(RT07)**
- [x] Todos os textos, hints, erros e títulos em `strings.xml` **(RT07)**
- [x] Ícones do menu em `res/drawable` (Vector Asset)
- [x] `res/menu/menu_bottom.xml` com `nav_livros`, `nav_novo`, `nav_resumo` (títulos via `@string`)
- [x] `NavegacaoMenu.java` com `configurar(Activity, int)` e `irPara(Activity, Intent)` — TODO do Anexo A completo **(RT09)**
- [x] `setSelectedItemId` antes de `setOnItemSelectedListener`
- [x] `RecyclerItemClickListener.java` (versão do Anexo B)

## Passo 4 — Telas e Activities
### Geral
- [x] Inset listener com `bottom = 0` nas 3 Activities
- [x] `BottomNavigationView` (`@+id/bottomNav`) como último elemento dos 3 layouts
- [x] As 3 Activities registradas no `AndroidManifest.xml`

### Listagem — `ListaLivrosActivity` / `activity_lista_livros.xml` / `adapter_livro.xml`
- [x] ConstraintLayout com RecyclerView `layout_height="0dp"` entre cabeçalho e menu **(RT06)**
- [x] `LinearLayoutManager` **(RT06)**
- [x] `adapter/AdapterLivro.java` com `atualizarLista(List<Livro>)` + `notifyDataSetChanged()` e `getLivro(int)` **(RT04)**
- [x] Item exibe título, autor/ano e indicador visual Lido / Não lido **(RF02)**
- [x] Dados carregados em `onResume()` **(RT05)**
- [x] Clique simples → `adapter.getLivro(position)` + `putExtra` + `NavegacaoMenu.irPara(...)` **(RF03, RT08)**
- [x] Clique longo → `AlertDialog` de confirmação → exclui e recarrega a lista sem recriar a Activity **(RF04)**
- [x] Toast de sucesso/falha na exclusão **(RF06)**

### Cadastro/Edição — `CadastroLivroActivity` / `activity_cadastro_livro.xml`
- [x] EditText título, autor, ano (`inputType="number"`), CheckBox "Já li este livro", botão principal
- [x] Recebe `Livro` via `getSerializableExtra`, preenche campos e muda botão para "Atualizar" (`getString`) **(RF03, RT08)**
- [x] Validação com `setError` (título, autor vazios; ano vazio antes do `parseInt`; ano entre 1450 e ano atual via `Calendar`) **(RF01)**
- [x] Chama `salvar` ou `atualizar` e exibe Toast de sucesso/falha **(RF06)**
- [x] Após salvar → `NavegacaoMenu.irPara(..., ListaLivrosActivity)` (sem `finish()` sozinho) **(RT09)**

### Resumo — `ResumoActivity` / `activity_resumo.xml`
- [x] Três TextView: total, lidos, não lidos
- [x] Preenchidos com `dao.contar(null)`, `dao.contar(true)`, `dao.contar(false)` **(RF05)**

### Regras gerais
- [x] Nenhuma variável `static` compartilhada para passar dados **(RT08)**
- [x] Nenhum texto/cor fixo no Java ou XML (Toast, setError, AlertDialog, botão) **(RT07)**

## Passo 5 — Testes e empacotamento
- [x] Projeto compila (`gradlew assembleDebug`)
- [x] Teste no emulador: salvar em branco (setError)
- [x] Teste: cadastrar 3 livros (lidos e não lidos) e conferir ordem alfabética
- [x] Teste: editar um registro
- [x] Teste: excluir com clique longo
- [x] Teste: contadores na tela Resumo
- [x] Remover `build` e `.gradle` e compactar em `.zip` (`AndroidStudioProjects\BibliotecaPessoal.zip`)
- [ ] Gravar vídeo de demonstração

---

## Registro de verificação (24/11/2026)
- `gradlew assembleDebug` compila sem erros (único aviso: `getSerializableExtra` obsoleto, uso exigido pelo RT08).
- Testado no emulador Pixel_4: setError nos 3 campos em branco; ano 3000 → "O ano deve estar entre 1450 e 2026";
  cadastro de O Hobbit, Dom Casmurro e Clean Code (lista em ordem alfabética, tags Lido/Não lido);
  edição de Dom Casmurro (botão "Atualizar", marcado como lido); exclusão de O Hobbit via clique longo + AlertDialog;
  Resumo exibindo Total 2 / Lidos 2 / Não lidos 0. Toasts exibidos em todas as operações.
- Pendente (manual): compactar o projeto sem `build`/`.gradle` e gravar o vídeo de demonstração.
