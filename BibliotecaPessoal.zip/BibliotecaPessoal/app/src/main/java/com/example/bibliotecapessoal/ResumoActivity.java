package com.example.bibliotecapessoal;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.bibliotecapessoal.persistencia.LivroDAO;

public class ResumoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_resumo);
        // bottom = 0: o BottomNavigationView já trata a margem inferior
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, 0);
            return insets;
        });

        NavegacaoMenu.configurar(this, R.id.nav_resumo);

        LivroDAO dao = new LivroDAO(getApplicationContext());

        TextView textTotal = findViewById(R.id.textTotal);
        TextView textLidos = findViewById(R.id.textLidos);
        TextView textNaoLidos = findViewById(R.id.textNaoLidos);

        // Contadores obtidos exclusivamente via SELECT COUNT(*)
        textTotal.setText(getString(R.string.resumo_total, dao.contar(null)));
        textLidos.setText(getString(R.string.resumo_lidos, dao.contar(true)));
        textNaoLidos.setText(getString(R.string.resumo_nao_lidos, dao.contar(false)));
    }
}
