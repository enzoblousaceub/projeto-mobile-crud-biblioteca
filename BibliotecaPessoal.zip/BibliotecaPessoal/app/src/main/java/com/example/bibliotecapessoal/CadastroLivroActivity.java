package com.example.bibliotecapessoal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.bibliotecapessoal.model.Livro;
import com.example.bibliotecapessoal.persistencia.LivroDAO;

import java.util.Calendar;

public class CadastroLivroActivity extends AppCompatActivity {

    private static final int ANO_MINIMO = 1450;

    private EditText edtTitulo;
    private EditText edtAutor;
    private EditText edtAno;
    private CheckBox checkLido;
    private Button btnSalvar;

    private LivroDAO dao;
    private Livro livroAtual; // null = inclusão; preenchido = edição

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cadastro_livro);
        // bottom = 0: o BottomNavigationView já trata a margem inferior
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, 0);
            return insets;
        });

        NavegacaoMenu.configurar(this, R.id.nav_novo);

        dao = new LivroDAO(getApplicationContext());
        edtTitulo = findViewById(R.id.edtTitulo);
        edtAutor = findViewById(R.id.edtAutor);
        edtAno = findViewById(R.id.edtAno);
        checkLido = findViewById(R.id.checkLido);
        btnSalvar = findViewById(R.id.btnSalvar);
        TextView textCabecalho = findViewById(R.id.textCabecalho);

        // Modo edição: livro recebido pela Intent
        livroAtual = (Livro) getIntent().getSerializableExtra(ListaLivrosActivity.EXTRA_LIVRO);
        if (livroAtual != null) {
            edtTitulo.setText(livroAtual.getTitulo());
            edtAutor.setText(livroAtual.getAutor());
            edtAno.setText(String.valueOf(livroAtual.getAno()));
            checkLido.setChecked(livroAtual.isLido());
            btnSalvar.setText(getString(R.string.btn_atualizar));
            textCabecalho.setText(getString(R.string.titulo_edicao));
        }

        btnSalvar.setOnClickListener(v -> salvar());
    }

    private void salvar() {
        String titulo = edtTitulo.getText().toString().trim();
        String autor = edtAutor.getText().toString().trim();
        String textoAno = edtAno.getText().toString().trim();

        boolean valido = true;

        if (titulo.isEmpty()) {
            edtTitulo.setError(getString(R.string.erro_titulo_obrigatorio));
            valido = false;
        }
        if (autor.isEmpty()) {
            edtAutor.setError(getString(R.string.erro_autor_obrigatorio));
            valido = false;
        }

        // Ano atual, sem escrever o número fixo no código
        int anoAtual = Calendar.getInstance().get(Calendar.YEAR);
        int ano = 0;
        if (textoAno.isEmpty()) { // confira ANTES do parseInt
            edtAno.setError(getString(R.string.erro_ano_obrigatorio));
            valido = false;
        } else {
            try {
                ano = Integer.parseInt(textoAno);
                if (ano < ANO_MINIMO || ano > anoAtual) {
                    edtAno.setError(getString(R.string.erro_ano_intervalo, ANO_MINIMO, anoAtual));
                    valido = false;
                }
            } catch (NumberFormatException e) {
                edtAno.setError(getString(R.string.erro_ano_intervalo, ANO_MINIMO, anoAtual));
                valido = false;
            }
        }

        if (!valido) {
            return;
        }

        boolean sucesso;
        if (livroAtual == null) {
            sucesso = dao.salvar(new Livro(titulo, autor, ano, checkLido.isChecked()));
            Toast.makeText(this,
                    sucesso ? R.string.msg_salvo_sucesso : R.string.msg_salvo_erro,
                    Toast.LENGTH_SHORT).show();
        } else {
            livroAtual.setTitulo(titulo);
            livroAtual.setAutor(autor);
            livroAtual.setAno(ano);
            livroAtual.setLido(checkLido.isChecked());
            sucesso = dao.atualizar(livroAtual);
            Toast.makeText(this,
                    sucesso ? R.string.msg_atualizado_sucesso : R.string.msg_atualizado_erro,
                    Toast.LENGTH_SHORT).show();
        }

        if (sucesso) {
            // NÃO usar finish() sozinho: a lista já foi encerrada
            NavegacaoMenu.irPara(this, new Intent(this, ListaLivrosActivity.class));
        }
    }
}
