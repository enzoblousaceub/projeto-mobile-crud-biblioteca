package com.example.bibliotecapessoal.persistencia;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.example.bibliotecapessoal.model.Livro;

import java.util.ArrayList;
import java.util.List;

public class LivroDAO implements ILivroDAO {

    private static final String TAG = "LivroDAO";

    private final SQLiteDatabase escreve;
    private final SQLiteDatabase le;

    public LivroDAO(Context context) {
        DbHelper db = new DbHelper(context);
        escreve = db.getWritableDatabase();
        le = db.getReadableDatabase();
    }

    // Converte o objeto em ContentValues (boolean -> INTEGER 0/1)
    private ContentValues toContentValues(Livro livro) {
        ContentValues cv = new ContentValues();
        cv.put(DbHelper.COLUNA_TITULO, livro.getTitulo());
        cv.put(DbHelper.COLUNA_AUTOR, livro.getAutor());
        cv.put(DbHelper.COLUNA_ANO, livro.getAno());
        cv.put(DbHelper.COLUNA_LIDO, livro.isLido() ? 1 : 0);
        return cv;
    }

    @Override
    public boolean salvar(Livro livro) {
        try {
            long id = escreve.insert(DbHelper.TABELA_LIVROS, null, toContentValues(livro));
            if (id != -1) {
                livro.setId(id);
                return true;
            }
        } catch (Exception e) {
            Log.e(TAG, "Erro ao salvar livro: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean atualizar(Livro livro) {
        try {
            String[] args = {String.valueOf(livro.getId())};
            int linhasAfetadas = escreve.update(DbHelper.TABELA_LIVROS, toContentValues(livro),
                    DbHelper.COLUNA_ID + "=?", args);
            return linhasAfetadas > 0;
        } catch (Exception e) {
            Log.e(TAG, "Erro ao atualizar livro: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean excluir(Livro livro) {
        try {
            String[] args = {String.valueOf(livro.getId())};
            int linhasAfetadas = escreve.delete(DbHelper.TABELA_LIVROS,
                    DbHelper.COLUNA_ID + "=?", args);
            return linhasAfetadas > 0;
        } catch (Exception e) {
            Log.e(TAG, "Erro ao excluir livro: " + e.getMessage());
        }
        return false;
    }

    @Override
    public List<Livro> listarTodos() {
        List<Livro> livros = new ArrayList<>();
        String sql = "SELECT * FROM " + DbHelper.TABELA_LIVROS
                + " ORDER BY " + DbHelper.COLUNA_TITULO + " COLLATE NOCASE ASC;";

        try (Cursor c = le.rawQuery(sql, null)) {
            int idxId = c.getColumnIndexOrThrow(DbHelper.COLUNA_ID);
            int idxTitulo = c.getColumnIndexOrThrow(DbHelper.COLUNA_TITULO);
            int idxAutor = c.getColumnIndexOrThrow(DbHelper.COLUNA_AUTOR);
            int idxAno = c.getColumnIndexOrThrow(DbHelper.COLUNA_ANO);
            int idxLido = c.getColumnIndexOrThrow(DbHelper.COLUNA_LIDO);

            while (c.moveToNext()) {
                Livro livro = new Livro();
                livro.setId(c.getLong(idxId));
                livro.setTitulo(c.getString(idxTitulo));
                livro.setAutor(c.getString(idxAutor));
                livro.setAno(c.getInt(idxAno));
                livro.setLido(c.getInt(idxLido) == 1); // INTEGER -> boolean
                livros.add(livro);
            }
        } catch (Exception e) {
            Log.e(TAG, "Erro ao listar livros: " + e.getMessage());
        }
        return livros;
    }

    @Override
    public int contar(Boolean lido) {
        String sql = "SELECT COUNT(*) FROM " + DbHelper.TABELA_LIVROS;
        String[] args = null;
        if (lido != null) {
            sql += " WHERE " + DbHelper.COLUNA_LIDO + " = ?";
            args = new String[]{lido ? "1" : "0"};
        }

        try (Cursor c = le.rawQuery(sql, args)) {
            if (c.moveToFirst()) {
                return c.getInt(0);
            }
        } catch (Exception e) {
            Log.e(TAG, "Erro ao contar livros: " + e.getMessage());
        }
        return 0;
    }
}
