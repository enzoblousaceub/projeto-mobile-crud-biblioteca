package com.example.bibliotecapessoal.adapter;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bibliotecapessoal.R;
import com.example.bibliotecapessoal.model.Livro;

import java.util.ArrayList;
import java.util.List;

public class AdapterLivro extends RecyclerView.Adapter<AdapterLivro.MyViewHolder> {

    private List<Livro> listaLivros;

    public AdapterLivro(List<Livro> listaLivros) {
        this.listaLivros = listaLivros != null ? listaLivros : new ArrayList<>();
    }

    // Substitui a lista interna e redesenha o RecyclerView
    public void atualizarLista(List<Livro> novaLista) {
        this.listaLivros = novaLista != null ? novaLista : new ArrayList<>();
        notifyDataSetChanged();
    }

    // Devolve o livro da posição informada
    public Livro getLivro(int position) {
        return listaLivros.get(position);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemLista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.adapter_livro, parent, false);
        return new MyViewHolder(itemLista);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Livro livro = listaLivros.get(position);
        Context context = holder.itemView.getContext();

        holder.titulo.setText(livro.getTitulo());
        holder.autorAno.setText(context.getString(R.string.formato_autor_ano,
                livro.getAutor(), livro.getAno()));

        // Indicador visual: tag com texto e cor diferentes para lido / não lido
        int corTag = ContextCompat.getColor(context,
                livro.isLido() ? R.color.status_lido : R.color.status_nao_lido);
        holder.status.setText(livro.isLido() ? R.string.status_lido : R.string.status_nao_lido);
        holder.status.setBackgroundTintList(ColorStateList.valueOf(corTag));
        holder.indicador.setBackgroundColor(corTag);
    }

    @Override
    public int getItemCount() {
        return listaLivros.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        final View indicador;
        final TextView titulo;
        final TextView autorAno;
        final TextView status;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            indicador = itemView.findViewById(R.id.viewIndicador);
            titulo = itemView.findViewById(R.id.textTitulo);
            autorAno = itemView.findViewById(R.id.textAutorAno);
            status = itemView.findViewById(R.id.textStatus);
        }
    }
}
