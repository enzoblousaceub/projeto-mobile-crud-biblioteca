# Atividade Avaliativa — App Biblioteca Pessoal

**Valor:** 30% da Menção 3

## Objetivo

Desenvolver em Android (Java + SQLite) o aplicativo **Biblioteca Pessoal**, um cadastro de livros. O app segue a mesma estrutura do Gestão de Contatos visto em aula: model, persistência (DbHelper + DAO), adapter e RecyclerView.

## O que o app deve fazer

- Cadastrar livros com título, autor, ano e se já foi lido, validando os campos.
- Listar os livros em ordem alfabética, indicando quais já foram lidos.
- Editar um livro ao tocar nele e excluí-lo com toque longo, após confirmação.
- Mostrar um resumo com o total de livros, os lidos e os não lidos.
- Navegar entre as três telas (Livros, Novo e Resumo) por um menu inferior.

Os requisitos completos, o passo a passo e os critérios de correção estão no PDF anexo (`Exercicio_Avaliativo_Biblioteca_Pessoal.pdf`).

**Anexo:** Exercicio_Avaliativo_Biblioteca_Pessoal.pdf — 18 novembro 2026, 08:27:53
