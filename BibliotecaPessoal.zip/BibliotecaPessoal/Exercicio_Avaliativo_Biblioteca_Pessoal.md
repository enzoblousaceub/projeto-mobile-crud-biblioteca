**DESENVOLVIMENTO ANDROID · JAVA + SQLITE**

# Exercício Avaliativo — App Biblioteca Pessoal

*CRUD completo com SQLite, RecyclerView e menu inferior (BottomNavigationView)*

---

## 1. Contexto e Objetivo

O aluno deverá construir o aplicativo **Biblioteca Pessoal**, um CRUD completo em Android (Java + SQLite) que reaproveita a arquitetura em camadas vista em aula no app Gestão de Contatos: `model`, `persistencia` (DbHelper + interface DAO + classe DAO), `adapter` e `RecyclerView`.

Este exercício avalia três evoluções técnicas em relação ao projeto base:

1. **Persistência tipada:** armazenar tipos além de texto — inteiro (ano) e booleano (lido / não lido, persistido no SQLite como INTEGER 0 ou 1).
2. **Ciclo completo de CRUD na UI:** listar registros ordenados, editar via clique simples e excluir via clique longo com diálogo de confirmação.
3. **Navegação unificada:** alternar entre três Activities por meio de um menu inferior (BottomNavigationView) presente em todas as telas, centralizando a lógica de navegação em uma única classe utilitária.

## 2. Visão Geral e Fluxo das Telas

O aplicativo possui três Activities. Todas exibem o mesmo menu inferior (BottomNavigationView) com três opções.

**Regra de navegação:** toda troca de tela — pelo menu, pelo clique para editar ou pelo retorno após salvar — é feita com `startActivity(...)` seguido de `finish()` da tela atual, por meio do método `NavegacaoMenu.irPara(...)`. Assim só existe uma tela aberta por vez.

| Item do menu | Activity | Responsabilidade principal |
|---|---|---|
| Livros | `ListaLivrosActivity` (LAUNCHER) | Exibe todos os livros cadastrados em um RecyclerView, ordenados alfabeticamente pelo título. Clique simples abre o formulário para edição; clique longo solicita confirmação e exclui o registro. |
| Novo | `CadastroLivroActivity` | Formulário unificado de inclusão e edição. Ao concluir a operação com sucesso, abre a tela Livros com `NavegacaoMenu.irPara(...)`. |
| Resumo | `ResumoActivity` | Apresenta os indicadores do acervo: total de livros, total de lidos e total de não lidos. |

### Referência visual das telas (wireframes)

```
+-----------------------------+ +-----------------------------+ +-----------------------------+
| Meus Livros                 | | Cadastro de Livro           | | Resumo da Biblioteca        |
+-----------------------------+ +-----------------------------+ +-----------------------------+
| Clean Code          [Lido]  | | [ Título do livro       ]   | | Total de livros: 12         |
| Robert C. Martin • 2008     | | [ Autor                 ]   | | Livros lidos: 8             |
| --------------------------- | | [ Ano de publicação     ]   | | Livros não lidos: 4         |
| Dom Casmurro    [Não lido]  | | [x] Já li este livro        | |                             |
| Machado de Assis • 1899     | |                             | |                             |
| --------------------------- | | [  SALVAR / ATUALIZAR  ]    | |                             |
| O Hobbit            [Lido]  | |                             | |                             |
| J.R.R. Tolkien • 1937       | |                             | |                             |
+-----------------------------+ +-----------------------------+ +-----------------------------+
| [Livros] [Novo] [Resumo]    | | [Livros] [Novo] [Resumo]    | | [Livros] [Novo] [Resumo]    |
+-----------------------------+ +-----------------------------+ +-----------------------------+
  Tela 1: ListaLivrosActivity     Tela 2: CadastroLivroActivity   Tela 3: ResumoActivity
```

## 3. Modelo de Dados — Entidade Livro

A classe `Livro` deve implementar `Serializable` para permitir o tráfego entre Activities via Intent.

| Atributo | Tipo Java | Coluna SQLite | Restrições e regras de negócio |
|---|---|---|---|
| id | Long | INTEGER PRIMARY KEY AUTOINCREMENT | Chave primária gerada automaticamente pelo SQLite. |
| titulo | String | TEXT NOT NULL | Obrigatório (não pode ser vazio ou apenas espaços). |
| autor | String | TEXT NOT NULL | Obrigatório (não pode ser vazio ou apenas espaços). |
| ano | int | INTEGER | Obrigatório; inteiro entre 1450 e o ano corrente. |
| lido | boolean | INTEGER (0 ou 1) | CheckBox ou Switch no formulário (true = 1, false = 0). |

## 4. Requisitos Funcionais (RF)

**RF01 — Validação no cadastro/edição:** ao acionar o botão de salvar, validar todos os campos. Caso algum campo obrigatório esteja vazio ou o ano esteja fora do intervalo (1450 até o ano atual), exibir a mensagem de erro no respectivo EditText via `setError(...)` e interromper a gravação. O ano atual deve ser obtido com `Calendar`, não escrito fixo no código.

**RF02 — Listagem e indicador visual:** listar todos os livros ordenados por `titulo` (ASC). Cada item deve exibir o título, o autor/ano e um indicador visual claro diferenciando Lidos de Não lidos (cor de destaque, tag ou ícone).

**RF03 — Edição por clique simples:** tocar em um item da lista deve abrir a `CadastroLivroActivity` com os campos preenchidos com os dados do livro selecionado e alterar o texto do botão principal para "Atualizar".

**RF04 — Exclusão com confirmação:** pressionar e segurar (clique longo) um item deve exibir um `AlertDialog` pedindo a confirmação da exclusão. Caso o usuário confirme, remover o registro do banco e atualizar o RecyclerView imediatamente, sem recriar a Activity.

**RF05 — Estatísticas via SQL:** na `ResumoActivity`, os três contadores (total, lidos e não lidos) devem ser obtidos exclusivamente por consultas SQL (`SELECT COUNT(*)`). É proibido carregar a lista completa em memória para contar com laço (for/while).

**RF06 — Feedback ao usuário:** toda operação de inclusão, edição ou exclusão (sucesso ou falha) deve exibir feedback visual por meio de Toast ou Snackbar.

## 5. Requisitos Técnicos e Arquitetura (RT)

O projeto deve obedecer à seguinte organização de pacotes e recursos:

```
com.example.bibliotecapessoal
├── ListaLivrosActivity.java          (LAUNCHER)
├── CadastroLivroActivity.java
├── ResumoActivity.java
├── NavegacaoMenu.java                (menu inferior e navegação entre as 3 telas)
├── RecyclerItemClickListener.java    (use a versão do Anexo B)
├── model/
│   └── Livro.java
├── persistencia/
│   ├── DbHelper.java
│   ├── ILivroDAO.java
│   └── LivroDAO.java
└── adapter/
    └── AdapterLivro.java

res/
├── menu/
│   └── menu_bottom.xml
├── values/
│   ├── strings.xml
│   └── colors.xml
└── layout/
    ├── activity_lista_livros.xml
    ├── activity_cadastro_livro.xml
    ├── activity_resumo.xml
    └── adapter_livro.xml
```

**RT01 — Contrato DAO:** a interface `ILivroDAO` deve declarar exatamente os métodos `salvar(Livro)`, `atualizar(Livro)`, `excluir(Livro)`, `listarTodos()` e `contar(Boolean lido)` (`null` retorna o total geral, `true` os lidos e `false` os não lidos).

**RT02 — Verificação de persistência:** em `LivroDAO`, os métodos de escrita devem validar o retorno do `SQLiteDatabase`: `insert` deve retornar valor diferente de -1, e `update` / `delete` devem retornar linhas afetadas > 0 para devolver `true`.

**RT03 — Gerenciamento do banco:** `DbHelper` deve declarar o nome do banco, a versão, o nome da tabela e os nomes das colunas como constantes `public static final`. O banco é entregue na versão 1, e o `onUpgrade(...)` deve conter a migração para a versão 2, que acrescenta a coluna `nota INTEGER` via `ALTER TABLE` quando `oldVersion < 2`, sem apagar a tabela.

**RT04 — Adapter:** `AdapterLivro` deve expor dois métodos públicos: `atualizarLista(List<Livro> novaLista)`, que substitui a lista interna e invoca `notifyDataSetChanged()`, e `getLivro(int position)`, que devolve o livro da posição. Os cliques da lista devem obter o livro por `getLivro(...)`, nunca por uma cópia da lista guardada na Activity.

**RT05 — Ciclo de vida:** `ListaLivrosActivity` deve carregar os dados do banco no método `onResume()`.

**RT06 — Restrições de layout:** o RecyclerView deve usar `LinearLayoutManager` e estar posicionado em ConstraintLayout com `android:layout_height="0dp"`, restrito entre o cabeçalho da tela e o topo do BottomNavigationView.

**RT07 — Externalização de recursos:** todos os textos visíveis devem estar em `res/values/strings.xml` e todas as cores em `res/values/colors.xml`. Isso vale para os layouts, para os títulos do `menu_bottom.xml` e também para os textos definidos no Java (Toast, `setError`, AlertDialog e o "Atualizar" do botão), que devem usar `getString(R.string...)`.

**RT08 — Passagem de parâmetros:** o objeto Livro selecionado para edição deve ser trafegado via Intent (`putExtra` / `getSerializableExtra`). É proibido o uso de variáveis `static` compartilhadas.

**RT09 — Navegação centralizada:** a configuração do BottomNavigationView e a troca de telas devem residir exclusivamente na classe `NavegacaoMenu`, com os métodos `configurar(Activity, int)` e `irPara(Activity, Intent)`, usados pelas três Activities (ver Anexo A).

## 6. Guia Passo a Passo

Para evitar erros de compilação e facilitar os testes no emulador, siga esta ordem no Android Studio.

### Passo 1: Criação e configuração do projeto

1. Crie um novo projeto com o template **Empty Views Activity**.
2. Defina o nome **Biblioteca Pessoal**, o pacote `com.example.bibliotecapessoal` e a linguagem **Java**.
3. O template cria uma `MainActivity`. Renomeie-a para `ListaLivrosActivity` (botão direito › Refactor › Rename), para que ela continue sendo a tela LAUNCHER no `AndroidManifest.xml`.
4. Abra `app/build.gradle` (ou `build.gradle.kts`) e verifique se a dependência do Material Design (`com.google.android.material:material`) está declarada. Se alterar algo, clique em **Sync Now**.
5. Crie os pacotes `model`, `persistencia` e `adapter` dentro de `java/com/example/bibliotecapessoal`.

### Passo 2: Camada de dados (Model e SQLite)

1. Em `model`, crie `Livro.java` com os atributos `id` (Long), `titulo` (String), `autor` (String), `ano` (int) e `lido` (boolean). Implemente `Serializable`, os construtores, getters e setters.
2. Em `persistencia`, crie `DbHelper.java` estendendo `SQLiteOpenHelper`. Declare as constantes `public static final` para o nome do banco, a versão (1), o nome da tabela (`livros`) e as colunas. No `onCreate`, execute o `CREATE TABLE` definindo `lido` como `INTEGER DEFAULT 0`. No `onUpgrade`, escreva a migração do RT03 (`ALTER TABLE livros ADD COLUMN nota INTEGER` quando `oldVersion < 2`).
3. Crie a interface `ILivroDAO.java` com os 5 métodos exigidos.
4. Implemente `LivroDAO.java` convertendo explicitamente entre boolean e INTEGER (`livro.isLido() ? 1 : 0` na gravação e `cursor.getInt(...) == 1` na leitura). Valide o retorno de `insert` (diferente de -1), `update` (> 0) e `delete` (> 0) e use `SELECT COUNT(*)` no método `contar`.

### Passo 3: Recursos visuais e navegação compartilhada

1. Cadastre todas as cores em `colors.xml` e todos os textos, dicas (hints), mensagens de erro e títulos em `strings.xml`.
2. Crie os ícones do menu em `res/drawable` › New › Vector Asset.
3. Crie `res/menu/menu_bottom.xml` com os três itens: `nav_livros`, `nav_novo` e `nav_resumo`.
4. Crie a classe `NavegacaoMenu.java` na raiz do pacote principal a partir do modelo do **Anexo A** e complete os itens que faltam.

### Passo 4: Telas (layouts XML) e Activities

**Em todas as telas:** o template coloca no `onCreate` um trecho que trata as barras do sistema. Ajuste-o assim, senão aparece um espaço duplo embaixo do menu:

```java
// ListaLivrosActivity.java (e nas outras duas)
// Trecho gerado pelo template: troque o último valor (bottom) por 0,
// porque o BottomNavigationView já trata a margem inferior sozinho
ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
    Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
    v.setPadding(systemBars.left, systemBars.top, systemBars.right, 0);
    return insets;
});
```

**Tela de listagem** (`activity_lista_livros.xml` e `ListaLivrosActivity.java`):

- No XML, use ConstraintLayout com o RecyclerView em `layout_height="0dp"`, entre o cabeçalho e o BottomNavigationView.
- Crie o layout do item (`adapter_livro.xml`) e a classe `AdapterLivro.java` com `atualizarLista(...)`, `getLivro(...)` e o destaque visual de lido / não lido.
- No `onResume()`, consulte `dao.listarTodos()` e atualize o adapter.
- Use o `RecyclerItemClickListener` do **Anexo B**. No clique simples, obtenha o livro com `adapter.getLivro(position)`, envie-o via `putExtra(...)` e abra o cadastro com `NavegacaoMenu.irPara(...)`. No clique longo, abra um `AlertDialog` e, ao confirmar, exclua do banco e recarregue a lista.

**Tela de cadastro/edição** (`activity_cadastro_livro.xml` e `CadastroLivroActivity.java`):

- Monte o formulário com EditText para título, autor e ano (`inputType="number"`), um CheckBox (ou Switch) "Já li este livro" e o botão principal.
- No `onCreate`, verifique se existe um Livro recebido via `getIntent().getSerializableExtra(...)`. Se existir, preencha os campos e mude o texto do botão para "Atualizar".
- Ao clicar no botão, valide título, autor e ano com `setError(...)`. Confira se o ano está vazio **antes** do `Integer.parseInt`, senão o app trava com `NumberFormatException`:

```java
// CadastroLivroActivity.java (trecho da validação)
// Ano atual, sem escrever o número fixo no código
int anoAtual = Calendar.getInstance().get(Calendar.YEAR);

String textoAno = edtAno.getText().toString().trim();
if (textoAno.isEmpty()) {             // confira ANTES do parseInt
    edtAno.setError(getString(R.string.erro_ano_obrigatorio));
    return;
}
int ano = Integer.parseInt(textoAno);
```

- Se tudo estiver válido, chame `salvar` ou `atualizar` no DAO, exiba um Toast e abra a lista com `NavegacaoMenu.irPara(...)`. **Não use `finish()` sozinho:** a lista já foi encerrada e o app fecharia.

**Tela de resumo** (`activity_resumo.xml` e `ResumoActivity.java`):

- Crie três TextView para o total de livros, os lidos e os não lidos.
- No `onCreate`, chame `dao.contar(null)`, `dao.contar(true)` e `dao.contar(false)` e preencha os textos.

### Passo 5: Testes e empacotamento final

1. Teste o fluxo completo no emulador: salvar em branco (conferir os `setError`), cadastrar 3 livros (lidos e não lidos), conferir a ordem alfabética, editar um registro, excluir outro com clique longo e verificar os contadores na tela Resumo.
2. Feche o Android Studio (ou limpe o projeto), remova as pastas `build` e `.gradle` e compacte tudo em um `.zip` para envio junto com o vídeo de demonstração.

> **Botão Voltar:** como cada troca de tela encerra a anterior, o botão Voltar do celular fecha o app em qualquer tela. Esse é o comportamento esperado em apps com menu inferior.

## 7. Critérios de Avaliação

A avaliação vai de 0,0 a 10,0 pontos. Cada critério é pontuado como integral (100%), parcial (50%, quando funciona com falhas ou desvios técnicos) ou zero (não implementado).

| Critério avaliado | Requisitos | Pontos |
|---|---|---|
| Modelo (Livro) e DbHelper com tipagem int/boolean, constantes e migração | RT03 | **1,0** |
| Camada DAO com interface, validação de retornos e COUNT via SQL | RT01, RT02, RF05 | **2,0** |
| Formulário de cadastro com validação por campo (setError) | RF01 | **1,0** |
| Listagem com Adapter, LayoutManager e indicador visual de leitura | RF02, RT04, RT06 | **1,5** |
| Edição (clique simples) e exclusão com confirmação (clique longo) | RF03, RF04, RT08 | **2,0** |
| Navegação inferior nas 3 telas centralizada em NavegacaoMenu, inclusive o retorno ao salvar | RT09 | **1,5** |
| Organização de pacotes, uso de strings.xml/colors.xml e código limpo | RT07 | **1,0** |
| **Total** | | **10,0** |

---

## Anexo A — Modelo da classe NavegacaoMenu

Ponto de partida para o RT09. O método `irPara` está completo; em `configurar`, complete os itens `nav_novo` e `nav_resumo`.

```java
// NavegacaoMenu.java
package com.example.bibliotecapessoal;

import android.app.Activity;
import android.content.Intent;
import android.view.MenuItem;

import androidx.annotation.NonNull;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class NavegacaoMenu {

    // Marca o item da tela atual e define para onde cada item do menu leva
    public static void configurar(final Activity activity, final int itemAtual) {
        BottomNavigationView nav = activity.findViewById(R.id.bottomNav);
        nav.setSelectedItemId(itemAtual); // ANTES do listener, senão dispara uma navegação

        nav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            // Abre a tela do item tocado, se não for a tela atual
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == itemAtual) {
                    return true;
                }
                if (id == R.id.nav_livros) {
                    irPara(activity, new Intent(activity, ListaLivrosActivity.class));
                }
                // TODO: tratar nav_novo e nav_resumo do mesmo jeito
                return true;
            }
        });
    }

    // Abre a tela de destino sem animação e encerra a atual
    public static void irPara(Activity origem, Intent intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        origem.startActivity(intent);
        origem.finish();
    }
}
```

Como usar nas Activities:

```java
// Uso nas Activities
// No onCreate de cada Activity, depois do setContentView:
NavegacaoMenu.configurar(this, R.id.nav_livros);   // em ListaLivrosActivity

// Clique simples na lista (editar):
Intent intent = new Intent(this, CadastroLivroActivity.class);
intent.putExtra("livroSelecionado", adapter.getLivro(position));
NavegacaoMenu.irPara(this, intent);

// Depois de salvar com sucesso no cadastro (NÃO use finish() sozinho):
NavegacaoMenu.irPara(this, new Intent(this, ListaLivrosActivity.class));
```

Menu inferior em cada layout:

```xml
<!-- activity_*.xml -->
<!-- Último elemento do ConstraintLayout em cada um dos 3 layouts -->
<com.google.android.material.bottomnavigation.BottomNavigationView
    android:id="@+id/bottomNav"
    android:layout_width="0dp"
    android:layout_height="wrap_content"
    app:menu="@menu/menu_bottom"
    app:layout_constraintBottom_toBottomOf="parent"
    app:layout_constraintStart_toStartOf="parent"
    app:layout_constraintEnd_toEndOf="parent" />
```

> **Ordem importa:** `setSelectedItemId` precisa vir antes de `setOnItemSelectedListener`. Na ordem inversa, marcar o item dispara o listener e a tela reabre sem parar.

## Anexo B — RecyclerItemClickListener (versão corrigida)

Use esta versão em vez da do Gestão de Contatos. Nela, a interface interna não herda de `AdapterView.OnItemClickListener`, e por isso a Activity só precisa implementar `onItemClick` e `onLongItemClick`.

```java
// RecyclerItemClickListener.java
package com.example.bibliotecapessoal;

import android.content.Context;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerItemClickListener implements RecyclerView.OnItemTouchListener {

    private final OnItemClickListener mListener;
    private final GestureDetector mGestureDetector;

    // Contrato que a Activity implementa para receber os cliques
    public interface OnItemClickListener {
        void onItemClick(View view, int position);

        void onLongItemClick(View view, int position);
    }

    // Prepara o detector de gestos para toque simples e toque longo
    public RecyclerItemClickListener(Context context, final RecyclerView recyclerView,
                                     OnItemClickListener listener) {
        mListener = listener;
        mGestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            // Confirma que o gesto foi um toque simples
            @Override
            public boolean onSingleTapUp(@NonNull MotionEvent e) {
                return true;
            }

            // Descobre o item pressionado e avisa o toque longo
            @Override
            public void onLongPress(@NonNull MotionEvent e) {
                View child = recyclerView.findChildViewUnder(e.getX(), e.getY());
                if (child != null && mListener != null) {
                    mListener.onLongItemClick(child, recyclerView.getChildAdapterPosition(child));
                }
            }
        });
    }

    // Intercepta o toque e avisa a Activity quando for um clique simples
    @Override
    public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
        View childView = rv.findChildViewUnder(e.getX(), e.getY());
        if (childView != null && mListener != null && mGestureDetector.onTouchEvent(e)) {
            mListener.onItemClick(childView, rv.getChildAdapterPosition(childView));
            return true;
        }
        return false;
    }

    // Não usado: o toque já é tratado em onInterceptTouchEvent
    @Override
    public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
    }

    // Não usado
    @Override
    public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {
    }
}
```
